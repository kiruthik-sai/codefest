import { View, Text } from 'react-native'
import React from 'react'

const DummyHome = () => {
  return (
    <View>
      <Text>DummyHome</Text>
    </View>
  )
}

export default DummyHome