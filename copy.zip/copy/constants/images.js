import bag1 from '../assets/images/products/bag1.png'
import bag2 from '../assets/images/products/bag2.png'
import bag3 from '../assets/images/products/bag3.png'
import bag4 from '../assets/images/products/bag4.png'
import bag5 from '../assets/images/products/bag5.png'
import bag6 from '../assets/images/products/bag6.png'
import bag7 from '../assets/images/products/bag7.png'
import bag8 from '../assets/images/products/bag8.png'
import bag9 from '../assets/images/products/bag9.png'
import bag10 from '../assets/images/products/bag10.png'
import bag11 from '../assets/images/products/bag11.png'

export default {
  bag1,
  bag2,
  bag3,
  bag4,
  bag5,
  bag6,
  bag7,
  bag8,
  bag9,
  bag10,
  bag11,
}
